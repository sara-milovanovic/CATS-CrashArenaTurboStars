package com.example.motions;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;

public class CustomView extends View {

    Paint p1=null;
    Paint p2=null;
    Paint p3=null;
    int index;
    ArrayList<Coordinate> list1=new ArrayList<>();
    ArrayList<Coordinate> list2=new ArrayList<>();
    Coordinate point=new Coordinate(50,50);

    public CustomView(Context context) {
        super(context);
        init();
    }

    public CustomView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init(){
        p1=new Paint();
        p1.setStrokeWidth(5);
        p1.setColor(getResources().getColor(R.color.colorAccent));
        p2=new Paint();
        p2.setStrokeWidth(5);
        p2.setColor(getResources().getColor(R.color.colorPrimary));
        p3=new Paint();
        p3.setStrokeWidth(5);
        p3.setColor(getResources().getColor(R.color.colorPrimaryDark));
    }

    public void down(){
        point.setY(point.getY()+10);
    }

    public static class Coordinate{
        float x, y;
        public Coordinate(float x, float y){
            this.x=x;
            this.y=y;
        }

        public float getX() {
            return x;
        }

        public void setX(float x) {
            this.x = x;
        }

        public float getY() {
            return y;
        }

        public void setY(float y) {
            this.y = y;
        }
    }

    public void add(Coordinate c, int list){
        if(list==1){
            list1.add(c);
        }
        else list2.add(c);
        index=list;
    }

    @Override
    protected void onDraw(Canvas canvas) {

            for (int i = 0; i < list1.size() - 1; i++) {
                canvas.drawLine(
                        list1.get(i).getX(),
                        list1.get(i).getY(),
                        list1.get(i + 1).getX(),
                        list1.get(i + 1).getY(),
                        p1);

            }

            canvas.drawCircle(point.getX(),point.getY(),4,p3);

            for (int i = 0; i < list2.size() - 1; i++) {
                canvas.drawLine(
                        list2.get(i).getX(),
                        list2.get(i).getY(),
                        list2.get(i + 1).getX(),
                        list2.get(i + 1).getY(),
                        p2);
            }

        super.onDraw(canvas);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}

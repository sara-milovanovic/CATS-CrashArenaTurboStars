package com.example.motions;

import android.os.AsyncTask;

public class MyAsyncTask extends AsyncTask<String,Void,Long> {

    CustomView customView;

    public MyAsyncTask(CustomView c){
        this.customView=c;
    }

    @Override
    protected Long doInBackground(String... strings) {
        try {

            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Long aLong) {
        customView.down();
        customView.invalidate();
        new MyAsyncTask(customView).execute();//DA BI SE STALNO POMERALO ILI U NITI PRAVITI A NE U ASYNC
        super.onPostExecute(aLong);
    }
}

package com.example.motions;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private float mLastTouchPositionX[];
    private float mLastTouchPositionY[];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mLastTouchPositionX=new float[5];
        mLastTouchPositionY=new float[5];
        for(int i=0;i<5;i++){ mLastTouchPositionY[i]=0; mLastTouchPositionX[i]=0; }
        final CustomView customView=findViewById(R.id.customView);
        GestureDetector.SimpleOnGestureListener onGestureListener=
                new GestureDetector.SimpleOnGestureListener(){
                    @Override
                    public boolean onDown(MotionEvent e) { return true; }
                };
        final GestureDetector gestureDetector=new GestureDetector(this,onGestureListener);
        customView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getActionMasked()){
                    case MotionEvent.ACTION_DOWN:{ Log.v("motion","DOWN"); break; }
                    case MotionEvent.ACTION_UP:{ Log.v("motion","UP"); break;  }
                    case MotionEvent.ACTION_MOVE:{
                        int tActionIndex = motionEvent.getActionIndex();
                        int tPointerCount = motionEvent.getPointerCount();
                        if (motionEvent.getActionMasked() == MotionEvent.ACTION_MOVE) {
                            for (int i = 0; i < tPointerCount && i < 5; i++) {
                                CustomView.Coordinate c=new CustomView.Coordinate(motionEvent.getX(i),motionEvent.getY(i));
                                customView.add(c,motionEvent.getPointerId(i));
                            }
                        }
                        customView.invalidate(); Log.v("motion","MOVE to "+motionEvent.getX(tActionIndex)+" , "+motionEvent.getY(tActionIndex)); break;
                    }
                }
                if(gestureDetector.onTouchEvent(motionEvent)){ return true; }
                return MainActivity.super.onTouchEvent(motionEvent);
            }
        });

        new MyAsyncTask(customView).execute();

    }
}
